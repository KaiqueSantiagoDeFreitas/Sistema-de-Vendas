package model;

import java.time.LocalDate;

public class Cliente {
    private int id;
    private String nome;
    private String status;
    private LocalDate dataCadastro;
    private double saldoDevedor;
    private double lucroObtido;

    public Cliente() {}

    public Cliente(String nome, String status, LocalDate dataCadastro) {
        this.nome = nome;
        this.status = status;
        this.dataCadastro = dataCadastro;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(LocalDate dataCadastro) { this.dataCadastro = dataCadastro; }

    public double getSaldoDevedor() { return saldoDevedor; }
    public void setSaldoDevedor(double saldoDevedor) { this.saldoDevedor = saldoDevedor; }

    public double getLucroObtido() { return lucroObtido; }
    public void setLucroObtido(double lucroObtido) { this.lucroObtido = lucroObtido; }

    @Override
    public String toString() {
        return this.id + " - " + this.nome;
    }
}
