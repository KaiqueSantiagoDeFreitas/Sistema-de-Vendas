package model;

public class Produto {
    private int id;
    private String nome;
    private String categoria;
    private double precoCompra;
    private double precoVenda;
    private int quantidade;

    public Produto() {}

    public Produto(String nome, String categoria, double precoCompra, double precoVenda, int quantidade) {
        this.nome = nome;
        this.categoria = categoria;
        this.precoCompra = precoCompra;
        this.precoVenda = precoVenda;
        this.quantidade = quantidade;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public double getPrecoCompra() { return precoCompra; }
    public void setPrecoCompra(double precoCompra) { this.precoCompra = precoCompra; }

    public double getPrecoVenda() { return precoVenda; }
    public void setPrecoVenda(double precoVenda) { this.precoVenda = precoVenda; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    @Override
    public String toString() {
        return this.nome + String.format(" - R$ %.2f (Disp: %d)", this.precoVenda, this.quantidade);
    }
}
