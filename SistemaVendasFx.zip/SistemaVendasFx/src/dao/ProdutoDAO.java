package dao;

import model.Produto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;

public class ProdutoDAO {

    public void inserir(Produto p) {
        boolean temIdManual = p.getId() > 0;
        String sql = temIdManual
            ? "INSERT INTO produto (id, nome, categoria, preco_compra, preco_venda, quantidade) VALUES (?, ?, ?, ?, ?, ?)"
            : "INSERT INTO produto (nome, categoria, preco_compra, preco_venda, quantidade) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            int idx = 1;
            if (temIdManual) stmt.setInt(idx++, p.getId());
            stmt.setString(idx++, p.getNome());
            stmt.setString(idx++, p.getCategoria());
            stmt.setDouble(idx++, p.getPrecoCompra());
            stmt.setDouble(idx++, p.getPrecoVenda());
            stmt.setInt(idx, p.getQuantidade());
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao inserir produto (verifique se o ID já existe): " + e.getMessage()).showAndWait();
        }
    }

    public void atualizar(Produto p, int idOriginal) {
        String sql = "UPDATE produto SET id=?, nome=?, categoria=?, preco_compra=?, preco_venda=?, quantidade=? WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, p.getId());
            stmt.setString(2, p.getNome());
            stmt.setString(3, p.getCategoria());
            stmt.setDouble(4, p.getPrecoCompra());
            stmt.setDouble(5, p.getPrecoVenda());
            stmt.setInt(6, p.getQuantidade());
            stmt.setInt(7, idOriginal);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao atualizar produto: " + e.getMessage()).showAndWait();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM produto WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao excluir produto: " + e.getMessage()).showAndWait();
        }
    }

    public List<Produto> listarTodos() {
        String sql = "SELECT * FROM produto ORDER BY id";
        List<Produto> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Produto p = new Produto();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCategoria(rs.getString("categoria"));
                p.setPrecoCompra(rs.getDouble("preco_compra"));
                p.setPrecoVenda(rs.getDouble("preco_venda"));
                p.setQuantidade(rs.getInt("quantidade"));
                lista.add(p);
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao listar produtos: " + e.getMessage()).showAndWait();
        }
        return lista;
    }
}