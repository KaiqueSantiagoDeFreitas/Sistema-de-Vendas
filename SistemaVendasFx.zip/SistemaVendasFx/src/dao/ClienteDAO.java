package dao;

import model.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;

public class ClienteDAO {

    public void inserir(Cliente c) {
        boolean temIdManual = c.getId() > 0;
        String sql = temIdManual
            ? "INSERT INTO cliente (id, nome, status, data_cadastro) VALUES (?, ?, ?, ?)"
            : "INSERT INTO cliente (nome, status, data_cadastro) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            int idx = 1;
            if (temIdManual) stmt.setInt(idx++, c.getId());
            stmt.setString(idx++, c.getNome());
            stmt.setString(idx++, c.getStatus());
            stmt.setDate(idx, Date.valueOf(c.getDataCadastro()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao inserir cliente (verifique se o ID já existe): " + e.getMessage()).showAndWait();
        }
    }

    public void atualizar(Cliente c, int idOriginal) {
        String sql = "UPDATE cliente SET id=?, nome=?, status=?, data_cadastro=? WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, c.getId());
            stmt.setString(2, c.getNome());
            stmt.setString(3, c.getStatus());
            stmt.setDate(4, Date.valueOf(c.getDataCadastro()));
            stmt.setInt(5, idOriginal);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao atualizar cliente: " + e.getMessage()).showAndWait();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM cliente WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao excluir cliente (verifique se há vendas vinculadas): " + e.getMessage()).showAndWait();
        }
    }

    public Cliente buscarPorId(int id) {
        String sql = "SELECT * FROM cliente WHERE id = ?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Cliente c = new Cliente();
                    c.setId(rs.getInt("id"));
                    c.setNome(rs.getString("nome"));
                    c.setStatus(rs.getString("status"));
                    c.setDataCadastro(rs.getDate("data_cadastro").toLocalDate());
                    return c;
                }
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao buscar cliente: " + e.getMessage()).showAndWait();
        }
        return null;
    }

    public List<Cliente> listarTodos() {
        String sql = "SELECT c.id, c.nome, c.status, c.data_cadastro, " +
                     "COALESCE(SUM(CASE WHEN v.pago = FALSE THEN v.valor_total ELSE 0 END), 0) AS saldo_devedor, " +
                     "COALESCE(SUM(v.lucro), 0) AS lucro_obtido " +
                     "FROM cliente c LEFT JOIN venda v ON c.id = v.cliente_id " +
                     "GROUP BY c.id, c.nome, c.status, c.data_cadastro ORDER BY c.id";
        List<Cliente> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                c.setStatus(rs.getString("status"));
                c.setDataCadastro(rs.getDate("data_cadastro").toLocalDate());
                c.setSaldoDevedor(rs.getDouble("saldo_devedor"));
                c.setLucroObtido(rs.getDouble("lucro_obtido"));
                lista.add(c);
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao listar clientes: " + e.getMessage()).showAndWait();
        }
        return lista;
    }
}