package dao;

import model.Cliente;
import model.Produto;
import model.Venda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;

public class VendaDAO {

    public void inserir(Venda v) {
        boolean temIdManual = v.getId() > 0;
        String sql = temIdManual
            ? "INSERT INTO venda (id, cliente_id, produto_id, quantidade, valor_total, lucro, data_venda, pago) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            : "INSERT INTO venda (cliente_id, produto_id, quantidade, valor_total, lucro, data_venda, pago) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlEstoque = "UPDATE produto SET quantidade = quantidade - ? WHERE id = ?";
        try (Connection conn = Conexao.getConnection()) {
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                int idx = 1;
                if (temIdManual) stmt.setInt(idx++, v.getId());
                stmt.setInt(idx++, v.getCliente().getId());
                stmt.setInt(idx++, v.getProduto().getId());
                stmt.setInt(idx++, v.getQuantidade());
                stmt.setDouble(idx++, v.getValorTotal());
                stmt.setDouble(idx++, v.getLucro());
                stmt.setDate(idx++, Date.valueOf(v.getDataVenda()));
                stmt.setBoolean(idx, v.isPago());
                stmt.executeUpdate();
            }
            try (PreparedStatement stmtEst = conn.prepareStatement(sqlEstoque)) {
                stmtEst.setInt(1, v.getQuantidade());
                stmtEst.setInt(2, v.getProduto().getId());
                stmtEst.executeUpdate();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao registrar venda (verifique se o ID já existe): " + e.getMessage()).showAndWait();
        }
    }

    public void atualizar(Venda v, int idOriginal) {
        String sql = "UPDATE venda SET id=?, cliente_id=?, produto_id=?, quantidade=?, valor_total=?, lucro=?, data_venda=?, pago=? WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, v.getId());
            stmt.setInt(2, v.getCliente().getId());
            stmt.setInt(3, v.getProduto().getId());
            stmt.setInt(4, v.getQuantidade());
            stmt.setDouble(5, v.getValorTotal());
            stmt.setDouble(6, v.getLucro());
            stmt.setDate(7, Date.valueOf(v.getDataVenda()));
            stmt.setBoolean(8, v.isPago());
            stmt.setInt(9, idOriginal);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao atualizar venda: " + e.getMessage()).showAndWait();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM venda WHERE id=?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao excluir venda: " + e.getMessage()).showAndWait();
        }
    }

    public List<Venda> listarTodos() {
        String sql = "SELECT v.*, c.nome AS cliente_nome, p.nome AS produto_nome, p.preco_compra, p.preco_venda, p.quantidade AS estoque_atual " +
                     "FROM venda v " +
                     "INNER JOIN cliente c ON v.cliente_id = c.id " +
                     "INNER JOIN produto p ON v.produto_id = p.id " +
                     "ORDER BY v.id";
        List<Venda> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getInt("cliente_id"));
                c.setNome(rs.getString("cliente_nome"));

                Produto p = new Produto();
                p.setId(rs.getInt("produto_id"));
                p.setNome(rs.getString("produto_nome"));
                p.setPrecoCompra(rs.getDouble("preco_compra"));
                p.setPrecoVenda(rs.getDouble("preco_venda"));
                p.setQuantidade(rs.getInt("estoque_atual"));

                Venda v = new Venda();
                v.setId(rs.getInt("id"));
                v.setCliente(c);
                v.setProduto(p);
                v.setQuantidade(rs.getInt("quantidade"));
                v.setValorTotal(rs.getDouble("valor_total"));
                v.setLucro(rs.getDouble("lucro"));
                v.setDataVenda(rs.getDate("data_venda").toLocalDate());
                v.setPago(rs.getBoolean("pago"));
                lista.add(v);
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "Erro ao listar vendas: " + e.getMessage()).showAndWait();
        }
        return lista;
    }
}