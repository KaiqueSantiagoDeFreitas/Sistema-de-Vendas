package controller;

import dao.ProdutoDAO;
import model.Produto;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class ProdutosController implements Initializable {

    @FXML private AnchorPane anchorInf;
    @FXML private AnchorPane anchorSup;
    @FXML private Button btnCancelar;
    @FXML private Button btnEditar;
    @FXML private Button btnExcluir;
    @FXML private Button btnNovo;
    @FXML private Button btnSalvar;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private TableColumn<Produto, String> colCategoria;
    @FXML private TableColumn<Produto, Integer> colIdProduto;
    @FXML private TableColumn<Produto, String> colNome;
    @FXML private TableColumn<Produto, Double> colPrecoCompra;
    @FXML private TableColumn<Produto, Double> colPrecoVenda;
    @FXML private TableColumn<Produto, Integer> colQuantidade;
    @FXML private GridPane formPane;
    @FXML private TableView<Produto> tblProdutos;
    @FXML private TextField txtIdProduto;
    @FXML private TextField txtNome;
    @FXML private TextField txtPrecoCompra;
    @FXML private TextField txtPrecoVenda;
    @FXML private TextField txtQuantidade;

    private ProdutoDAO dao = new ProdutoDAO();
    private Produto produtoSelecionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cmbCategoria.setItems(FXCollections.observableArrayList(
            "Capilar", "Corporal", "Estético", "Eletrodoméstico", "Perfumaria"
        ));

        colIdProduto.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colPrecoCompra.setCellValueFactory(new PropertyValueFactory<>("precoCompra"));
        colPrecoVenda.setCellValueFactory(new PropertyValueFactory<>("precoVenda"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));

        atualizarTabela();
    }

    private void atualizarTabela() {
        tblProdutos.setItems(FXCollections.observableArrayList(dao.listarTodos()));
    }

    @FXML
    void novoLivro(ActionEvent event) {
        limparCampos();
        txtNome.requestFocus();
    }

    @FXML
    void salvarLivro(ActionEvent event) {
        if (cmbCategoria.getValue() == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione uma categoria para o produto.").showAndWait();
            return;
        }
        try {
            Produto p = new Produto(
                txtNome.getText().trim(),
                cmbCategoria.getValue(),
                Double.parseDouble(txtPrecoCompra.getText().replace(",", ".")),
                Double.parseDouble(txtPrecoVenda.getText().replace(",", ".")),
                Integer.parseInt(txtQuantidade.getText().trim())
            );
            if (!txtIdProduto.getText().trim().isEmpty()) {
                p.setId(Integer.parseInt(txtIdProduto.getText().trim()));
            }
            dao.inserir(p);
            limparCampos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "Preencha ID, preços e quantidade com valores numéricos válidos.").showAndWait();
        }
    }

    @FXML
    void editarLivro(ActionEvent event) {
        if (produtoSelecionado == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione um produto na tabela para editar.").showAndWait();
            return;
        }
        try {
            int idOriginal = produtoSelecionado.getId();
            int novoId = txtIdProduto.getText().trim().isEmpty() ? idOriginal : Integer.parseInt(txtIdProduto.getText().trim());
            produtoSelecionado.setId(novoId);
            produtoSelecionado.setNome(txtNome.getText().trim());
            produtoSelecionado.setCategoria(cmbCategoria.getValue());
            produtoSelecionado.setPrecoCompra(Double.parseDouble(txtPrecoCompra.getText().replace(",", ".")));
            produtoSelecionado.setPrecoVenda(Double.parseDouble(txtPrecoVenda.getText().replace(",", ".")));
            produtoSelecionado.setQuantidade(Integer.parseInt(txtQuantidade.getText().trim()));
            dao.atualizar(produtoSelecionado, idOriginal);
            limparCampos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "Valores numéricos inválidos.").showAndWait();
        }
    }

    @FXML
    void excluirLivro(ActionEvent event) {
        if (produtoSelecionado == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione um produto na tabela para excluir.").showAndWait();
            return;
        }
        dao.excluir(produtoSelecionado.getId());
        limparCampos();
        atualizarTabela();
    }

    @FXML
    void cancelarEdicao(ActionEvent event) {
        limparCampos();
    }

    @FXML
    void selecionarProduto() {
        produtoSelecionado = tblProdutos.getSelectionModel().getSelectedItem();
        if (produtoSelecionado != null) {
            txtIdProduto.setText(String.valueOf(produtoSelecionado.getId()));
            txtNome.setText(produtoSelecionado.getNome());
            cmbCategoria.setValue(produtoSelecionado.getCategoria());
            txtPrecoCompra.setText(String.valueOf(produtoSelecionado.getPrecoCompra()));
            txtPrecoVenda.setText(String.valueOf(produtoSelecionado.getPrecoVenda()));
            txtQuantidade.setText(String.valueOf(produtoSelecionado.getQuantidade()));
        }
    }

    private void limparCampos() {
        txtIdProduto.clear();
        txtNome.clear();
        cmbCategoria.setValue(null);
        txtPrecoCompra.clear();
        txtPrecoVenda.clear();
        txtQuantidade.clear();
        produtoSelecionado = null;
    }
}