package controller;

import dao.ClienteDAO;
import model.Cliente;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class ClienteController implements Initializable {

    @FXML private AnchorPane anchorInf;
    @FXML private AnchorPane anchorSup;
    @FXML private Button btnCancelar;
    @FXML private Button btnEditar;
    @FXML private Button btnExcluir;
    @FXML private Button btnNovo;
    @FXML private Button btnSalvar;
    @FXML private ComboBox<String> cmbStarus;
    @FXML private TableColumn<Cliente, LocalDate> colData;
    @FXML private TableColumn<Cliente, Integer> colIdCliente;
    @FXML private TableColumn<Cliente, String> colIdVenda;
    @FXML private TableColumn<Cliente, String> colLucroObtido;
    @FXML private TableColumn<Cliente, String> colNome;
    @FXML private TableColumn<Cliente, String> colStatus;
    @FXML private DatePicker dpDataCompra;
    @FXML private GridPane formPane;
    @FXML private TableView<Cliente> tblLivros;
    @FXML private TextField txtIdCliente;
    @FXML private TextField txtIdVenda;
    @FXML private TextField txtcliente;

    private ClienteDAO dao = new ClienteDAO();
    private Cliente clienteSelecionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cmbStarus.setItems(FXCollections.observableArrayList("Ativo", "Inativo", "Inadimplente"));
        cmbStarus.setValue("Ativo");
        dpDataCompra.setValue(LocalDate.now());

        colIdCliente.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colIdVenda.setCellValueFactory(cell ->
            new SimpleStringProperty(String.format("R$ %.2f", cell.getValue().getSaldoDevedor()))
        );
        colLucroObtido.setCellValueFactory(cell ->
            new SimpleStringProperty(String.format("R$ %.2f", cell.getValue().getLucroObtido()))
        );
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colData.setCellValueFactory(new PropertyValueFactory<>("dataCadastro"));

        atualizarTabela();
    }

    private void atualizarTabela() {
        tblLivros.setItems(FXCollections.observableArrayList(dao.listarTodos()));
    }

    @FXML
    void novoLivro(ActionEvent event) {
        limparCampos();
        txtcliente.requestFocus();
    }

    @FXML
    void salvarLivro(ActionEvent event) {
        if (txtcliente.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Informe o nome do cliente.").showAndWait();
            return;
        }
        try {
            String status = cmbStarus.getValue() != null ? cmbStarus.getValue() : "Ativo";
            LocalDate data = dpDataCompra.getValue() != null ? dpDataCompra.getValue() : LocalDate.now();
            Cliente c = new Cliente(txtcliente.getText().trim(), status, data);
            if (!txtIdCliente.getText().trim().isEmpty()) {
                c.setId(Integer.parseInt(txtIdCliente.getText().trim()));
            }
            dao.inserir(c);
            limparCampos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "O ID deve ser um número inteiro válido.").showAndWait();
        }
    }

    @FXML
    void editarLivro(ActionEvent event) {
        if (clienteSelecionado == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione um cliente na tabela para editar.").showAndWait();
            return;
        }
        try {
            int idOriginal = clienteSelecionado.getId();
            int novoId = txtIdCliente.getText().trim().isEmpty() ? idOriginal : Integer.parseInt(txtIdCliente.getText().trim());
            clienteSelecionado.setId(novoId);
            clienteSelecionado.setNome(txtcliente.getText().trim());
            clienteSelecionado.setStatus(cmbStarus.getValue());
            clienteSelecionado.setDataCadastro(dpDataCompra.getValue());
            dao.atualizar(clienteSelecionado, idOriginal);
            limparCampos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "O ID deve ser um número inteiro válido.").showAndWait();
        }
    }

    @FXML
    void excluirLivro(ActionEvent event) {
        if (clienteSelecionado == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione um cliente na tabela para excluir.").showAndWait();
            return;
        }
        dao.excluir(clienteSelecionado.getId());
        limparCampos();
        atualizarTabela();
    }

    @FXML
    void cancelarEdicao(ActionEvent event) {
        limparCampos();
    }

    @FXML
    void selecionarCliente() {
        clienteSelecionado = tblLivros.getSelectionModel().getSelectedItem();
        if (clienteSelecionado != null) {
            txtIdCliente.setText(String.valueOf(clienteSelecionado.getId()));
            txtIdVenda.setText(String.format("R$ %.2f", clienteSelecionado.getSaldoDevedor()));
            txtcliente.setText(clienteSelecionado.getNome());
            cmbStarus.setValue(clienteSelecionado.getStatus());
            dpDataCompra.setValue(clienteSelecionado.getDataCadastro());
        }
    }

    private void limparCampos() {
        txtIdCliente.clear();
        txtIdVenda.clear();
        txtcliente.clear();
        cmbStarus.setValue("Ativo");
        dpDataCompra.setValue(LocalDate.now());
        clienteSelecionado = null;
    }
}