package controller;

import dao.Conexao;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class PrincipalController {

    @FXML private MenuItem ajudaSobre;
    @FXML private MenuItem arquivoFechar;
    @FXML private MenuItem arquivoHome;
    @FXML private MenuItem menuClientes;
    @FXML private MenuItem menuProdutos;
    @FXML private MenuItem menuVendas;
    @FXML private MenuItem relatoriosVendas;
    @FXML private MenuItem relatoriosInadimplencia;
    @FXML private AnchorPane painelPrincial;

    @FXML
    public void initialize() {
        abrirHome(null);
    }

    private void carregarTela(String caminho) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(caminho));
            Parent tela = fxmlLoader.load();
            AnchorPane.setTopAnchor(tela, 0.0);
            AnchorPane.setBottomAnchor(tela, 0.0);
            AnchorPane.setLeftAnchor(tela, 0.0);
            AnchorPane.setRightAnchor(tela, 0.0);
            painelPrincial.getChildren().setAll(tela);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void exibirRelatorio(String caminhoJrxml, String tituloJanela) {
        try (Connection conn = Conexao.getConnection();
             InputStream relatorioStream = getClass().getResourceAsStream(caminhoJrxml)) {
            JasperReport jasperReport = JasperCompileManager.compileReport(relatorioStream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conn);
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle(tituloJanela);
            viewer.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erro ao gerar relatório: " + e.getMessage()).showAndWait();
        }
    }

    @FXML void abrirHome(ActionEvent event) { carregarTela("/view/HomeView.fxml"); }
    @FXML void abrirClientes(ActionEvent event) { carregarTela("/view/ClienteView.fxml"); }
    @FXML void abrirProdutos(ActionEvent event) { carregarTela("/view/ProdutoView.fxml"); }
    @FXML void abrirVendas(ActionEvent event) { carregarTela("/view/VendaView.fxml"); }
    @FXML void abrirSobre(ActionEvent event) { carregarTela("/view/SobreView.fxml"); }

    @FXML
    void abrirRelatorioVendas(ActionEvent event) {
        exibirRelatorio("/relatorios/RelatorioVendasLucros.jrxml", "Relatório de Vendas e Lucros");
    }

    @FXML
    void abrirRelatorioInadimplencia(ActionEvent event) {
        exibirRelatorio("/relatorios/RelatorioInadimplencia.jrxml", "Relatório de Cobrança (Em Aberto)");
    }

    @FXML void menuFechar(ActionEvent event) { System.exit(0); }
}
