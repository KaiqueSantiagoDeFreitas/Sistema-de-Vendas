package controller;

import dao.ClienteDAO;
import dao.ProdutoDAO;
import dao.VendaDAO;
import model.Cliente;
import model.Produto;
import model.Venda;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class VendasController implements Initializable {

    @FXML private AnchorPane anchorInf;
    @FXML private AnchorPane anchorSup;
    @FXML private Button btnCancelar;
    @FXML private Button btnEditar;
    @FXML private Button btnExcluir;
    @FXML private Button btnNovo;
    @FXML private Button btnSalvar;
    @FXML private CheckBox chkStatusNaoPago;
    @FXML private CheckBox chkStatusPago;
    @FXML private ComboBox<Produto> cmbProduto;
    @FXML private TableColumn<Venda, String> colAtivo;
    @FXML private TableColumn<Venda, LocalDate> colDataCompra;
    @FXML private TableColumn<Venda, Integer> colIdCliente;
    @FXML private TableColumn<Venda, Integer> colIdVenda;
    @FXML private TableColumn<Venda, String> colProduto;
    @FXML private TableColumn<Venda, Integer> colQtd;
    @FXML private DatePicker dpDataLancamento;
    @FXML private GridPane formPane;
    @FXML private TableView<Venda> tblStatus;
    @FXML private TextField txtIdCliente;
    @FXML private TextField txtIdVenda;
    @FXML private TextField txtQtd;

    private VendaDAO vendaDAO = new VendaDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    private ProdutoDAO produtoDAO = new ProdutoDAO();
    private Venda vendaSelecionada;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colIdVenda.setCellValueFactory(new PropertyValueFactory<>("id"));
        colIdCliente.setCellValueFactory(cell ->
            new SimpleIntegerProperty(cell.getValue().getCliente().getId()).asObject()
        );
        colProduto.setCellValueFactory(cell ->
            new SimpleStringProperty(cell.getValue().getProduto().getNome() +
                String.format(" (Total: R$ %.2f | Lucro: R$ %.2f)", cell.getValue().getValorTotal(), cell.getValue().getLucro()))
        );
        colQtd.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colDataCompra.setCellValueFactory(new PropertyValueFactory<>("dataVenda"));
        colAtivo.setCellValueFactory(cell ->
            new SimpleStringProperty(cell.getValue().isPago() ? "Sim" : "Não")
        );

        dpDataLancamento.setValue(LocalDate.now());
        chkStatusNaoPago.setSelected(true);
        carregarProdutos();
        atualizarTabela();
    }

    @FXML
    public void carregarProdutos() {
        Produto atual = cmbProduto.getValue();
        cmbProduto.setItems(FXCollections.observableArrayList(produtoDAO.listarTodos()));
        if (atual != null) {
            cmbProduto.setValue(atual);
        }
    }

    @FXML
    void marcarPago(ActionEvent event) {
        if (chkStatusPago.isSelected()) {
            chkStatusNaoPago.setSelected(false);
        } else {
            chkStatusNaoPago.setSelected(true);
        }
    }

    @FXML
    void marcarNaoPago(ActionEvent event) {
        if (chkStatusNaoPago.isSelected()) {
            chkStatusPago.setSelected(false);
        } else {
            chkStatusPago.setSelected(true);
        }
    }

    private void atualizarTabela() {
        tblStatus.setItems(FXCollections.observableArrayList(vendaDAO.listarTodos()));
    }

    @FXML
    void novoLivro(ActionEvent event) {
        limparCampos();
        txtIdCliente.requestFocus();
    }

    @FXML
    void salvarLivro(ActionEvent event) {
        Produto p = cmbProduto.getValue();
        if (txtIdCliente.getText().trim().isEmpty() || p == null || txtQtd.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Informe o ID do cliente, o produto e a quantidade.").showAndWait();
            return;
        }
        try {
            int idCliente = Integer.parseInt(txtIdCliente.getText().trim());
            Cliente c = clienteDAO.buscarPorId(idCliente);
            if (c == null) {
                new Alert(Alert.AlertType.WARNING, "Cliente com ID " + idCliente + " não encontrado.").showAndWait();
                return;
            }
            int qtd = Integer.parseInt(txtQtd.getText().trim());
            if (qtd <= 0 || qtd > p.getQuantidade()) {
                new Alert(Alert.AlertType.WARNING, "Quantidade inválida ou maior que o estoque (" + p.getQuantidade() + ").").showAndWait();
                return;
            }

            Venda v = new Venda();
            if (!txtIdVenda.getText().trim().isEmpty()) {
                v.setId(Integer.parseInt(txtIdVenda.getText().trim()));
            }
            v.setCliente(c);
            v.setProduto(p);
            v.setQuantidade(qtd);
            v.setValorTotal(p.getPrecoVenda() * qtd);
            v.setLucro((p.getPrecoVenda() - p.getPrecoCompra()) * qtd);
            v.setDataVenda(dpDataLancamento.getValue() != null ? dpDataLancamento.getValue() : LocalDate.now());
            v.setPago(chkStatusPago.isSelected());

            vendaDAO.inserir(v);
            limparCampos();
            carregarProdutos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "IDs e quantidade devem ser números inteiros.").showAndWait();
        }
    }

    @FXML
    void editarLivro(ActionEvent event) {
        if (vendaSelecionada == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione uma venda na tabela para atualizar.").showAndWait();
            return;
        }
        try {
            int idOriginal = vendaSelecionada.getId();
            int novoId = txtIdVenda.getText().trim().isEmpty() ? idOriginal : Integer.parseInt(txtIdVenda.getText().trim());
            int idCliente = Integer.parseInt(txtIdCliente.getText().trim());
            Cliente c = clienteDAO.buscarPorId(idCliente);
            Produto p = cmbProduto.getValue();
            int qtd = Integer.parseInt(txtQtd.getText().trim());

            vendaSelecionada.setId(novoId);
            vendaSelecionada.setCliente(c);
            vendaSelecionada.setProduto(p);
            vendaSelecionada.setQuantidade(qtd);
            vendaSelecionada.setValorTotal(p.getPrecoVenda() * qtd);
            vendaSelecionada.setLucro((p.getPrecoVenda() - p.getPrecoCompra()) * qtd);
            vendaSelecionada.setDataVenda(dpDataLancamento.getValue());
            vendaSelecionada.setPago(chkStatusPago.isSelected());

            vendaDAO.atualizar(vendaSelecionada, idOriginal);
            limparCampos();
            atualizarTabela();
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.WARNING, "Verifique os valores informados.").showAndWait();
        }
    }

    @FXML
    void excluirLivro(ActionEvent event) {
        if (vendaSelecionada == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione uma venda na tabela para excluir.").showAndWait();
            return;
        }
        vendaDAO.excluir(vendaSelecionada.getId());
        limparCampos();
        atualizarTabela();
    }

    @FXML
    void cancelarEdicao(ActionEvent event) {
        limparCampos();
    }

    @FXML
    void selecionarVenda() {
        vendaSelecionada = tblStatus.getSelectionModel().getSelectedItem();
        if (vendaSelecionada != null) {
            txtIdVenda.setText(String.valueOf(vendaSelecionada.getId()));
            txtIdCliente.setText(String.valueOf(vendaSelecionada.getCliente().getId()));
            cmbProduto.setValue(vendaSelecionada.getProduto());
            txtQtd.setText(String.valueOf(vendaSelecionada.getQuantidade()));
            dpDataLancamento.setValue(vendaSelecionada.getDataVenda());
            chkStatusPago.setSelected(vendaSelecionada.isPago());
            chkStatusNaoPago.setSelected(!vendaSelecionada.isPago());
        }
    }

    private void limparCampos() {
        txtIdVenda.clear();
        txtIdCliente.clear();
        txtQtd.clear();
        dpDataLancamento.setValue(LocalDate.now());
        chkStatusPago.setSelected(false);
        chkStatusNaoPago.setSelected(true);
        vendaSelecionada = null;
    }
}